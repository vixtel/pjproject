#ifndef VERSION_H
#define VERSION_H

#ifdef GENERATED_VERSION_HEADER
#include "version_gen.h"
#else
#define VERSION_NUMBER "openh264 default: 1.4"
#endif

#endif // VERSION_H
